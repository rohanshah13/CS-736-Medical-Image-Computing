mri = "../data/histology_";
level = "noisy.png" ;
%% variables

gamma = 4;
a = 0.9;
%initial step size matters
step = 0.2;
max_itr = 100;
thr = 1e-8;
var=1;
option = 3;
%% main
y = imread(mri + level);
%gradient_descent(y,a,gamma,step,thr,max_itr,option)
%i = zeros(256,256,3);
[itr, itrs, i]  =  gradient_descent(y,a,var,gamma,step,thr,max_itr,option);

figure
imshow(uint8(i)+10);